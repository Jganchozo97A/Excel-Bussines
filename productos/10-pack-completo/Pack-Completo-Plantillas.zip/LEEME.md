# Pack Completo de Plantillas · Línea de productos digitales

Gracias por adquirir el pack completo. Incluye las 8 plantillas Excel profesionales de la línea,
listas para usar:

1. **Control de Gastos Personales** — registro de ingresos y gastos, dashboard, selector de moneda.
2. **Presupuesto Mensual** — presupuesto vs. real por categoría y mes, selector de mes y moneda.
3. **Control de Deudas** — seguimiento de deudas y pagos, estrategias de pago sugeridas (bola de nieve / avalancha).
4. **Control de Inventario** — catálogo de productos, entradas/salidas, alertas de stock bajo.
5. **Flujo de Caja para Negocios** — ingresos y egresos de efectivo, saldo de caja proyectado mes a mes.
6. **Contabilidad Básica para Emprendedores** — plan de cuentas y Estado de Resultados automático.
7. **Control de Ventas** — catálogo, clientes, registro de ventas y cobros pendientes.
8. **Nómina Básica** — planilla de colaboradores, bonificaciones, descuentos y sueldo neto.

*Este pack se comercializa como "Pack 10" y hoy incluye 8 plantillas; las próximas plantillas de
la línea (packs de plantillas adicionales) se sumarán a este pack sin costo extra para quienes ya
lo hayan comprado.*

## Cada plantilla incluye

- Dashboard con indicadores clave (KPIs) y gráficos automáticos
- Fórmulas automáticas (nada que calcular a mano)
- Resumen dinámico tipo tabla dinámica
- Listas desplegables y validación de datos
- Selector de moneda: local o USD, con tipo de cambio editable
- Hoja de instrucciones paso a paso
- Celdas y fórmulas protegidas (sin contraseña: Revisar → Desproteger hoja)
- Diseño profesional y ejemplos precargados

## Soporte

Para dudas o soporte sobre estas plantillas: www.tumarca.com

© Tu Marca de Plantillas
