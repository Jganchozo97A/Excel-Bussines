# Pack 5 Plantillas · Línea de productos digitales

Gracias por adquirir este pack. Incluye 5 plantillas Excel profesionales, listas para usar:

1. **Control de Gastos Personales** — registro de ingresos y gastos, dashboard, selector de moneda.
2. **Presupuesto Mensual** — presupuesto vs. real por categoría y mes, selector de mes y moneda.
3. **Control de Deudas** — seguimiento de deudas y pagos, estrategias de pago sugeridas (bola de nieve / avalancha).
4. **Flujo de Caja para Negocios** — ingresos y egresos de efectivo, saldo de caja proyectado mes a mes.
5. **Control de Ventas** — catálogo, clientes, registro de ventas y cobros pendientes.

## Cada plantilla incluye

- Dashboard con indicadores clave (KPIs) y gráficos automáticos
- Fórmulas automáticas (nada que calcular a mano)
- Resumen dinámico tipo tabla dinámica
- Listas desplegables y validación de datos
- Selector de moneda: local o USD, con tipo de cambio editable
- Hoja de instrucciones paso a paso
- Celdas y fórmulas protegidas (sin contraseña: Revisar → Desproteger hoja)
- Diseño profesional y ejemplos precargados

## Soporte

Para dudas o soporte sobre estas plantillas: www.tumarca.com

© Tu Marca de Plantillas
